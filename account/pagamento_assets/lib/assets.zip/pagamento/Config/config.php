<?php
    session_start();
 
require '../vendor/autoload.php';
 
$publicKey = "APP_USR-b7f48426-1296-4855-b9c7-6b0a659a4a29";   

MercadoPago\SDK::initialize();

$config = MercadoPago\SDK::config();
  

$config->set('ACCESS_TOKEN', 'APP_USR-315062509791954-051223-780cb205a0fedadcf5a89cff81ad1e70-498612904');   