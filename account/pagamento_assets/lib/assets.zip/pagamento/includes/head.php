<!--JQUERY-->
<?php //<script src="https://code.jquery.com/jquery-latest.js"></script>
//SE VOCÊ ATIVAR ESSE JQUERY ACIMA, O ESQUEMA DE ABAS VAI PARAR DE FUNCIONAR
//POIS VAI DAR CONFLITO COM O JQUERY CHAMADO NA PÁGINA INDEX
?>


<!--JQUERY VALIDATION-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/jquery.validate.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.17.0/additional-methods.min.js"></script>
<script src="js/jquery.validation-meus-metodos.js"></script>

<!--BOOTSTRAP-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>