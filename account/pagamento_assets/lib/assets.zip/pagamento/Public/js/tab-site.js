$('.menu .item')
  .tab();